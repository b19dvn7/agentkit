# CLAUDE.md — Spring Boot
# Production-tested agent config from the AgentKit bundle. Also valid as AGENTS.md / .cursorrules (rename + adjust the header).

## Project
> A Spring Boot project. Spring Boot REST service. Replace this with 1-2 sentences on what it does and who uses it.

## Stack
- Language: Java
- Category: Backend

## Commands
```bash
mvn install   # install
mvn spring-boot:run   # run / dev
mvn test   # test
mvn checkstyle:check   # lint
```
Run the relevant command and show output before claiming a task is done.

## Code style — Spring Boot
- Constructor injection, not @Autowired fields. Thin @RestControllers → @Services.
- DTOs at the boundary; never expose JPA entities directly.
- Favor immutability (records, final).

## Stack-specific gotchas (read these first)
- Lazy-loading outside a transaction throws LazyInitializationException — fetch what you need in the tx.
- N+1 from lazy associations — use fetch joins/entity graphs.
- Don't leak entities into the API layer (serialization + security).

## Testing
- JUnit 5 + MockMvc; @DataJpaTest for repos.

## How you should behave
- **Do only what is asked.** Implement exactly the requested change. Don't add features, refactors, or "while I'm here" improvements that weren't requested. Surface ideas; don't silently act on them.
- **Read before you write.** Open the relevant files first and match the existing patterns, naming, and structure. New code should be indistinguishable from the code already there.
- **Small, focused diffs.** Change the minimum needed. Never reformat or rename outside the task's scope.
- **Verify before claiming done.** Run the tests/build/linter and show the output. Never say it works without proof. If you can't verify, say so explicitly.
- **Ask when ambiguous.** One focused question beats a confident wrong guess.
- **No silent failures.** Handle errors and edge cases; don't swallow exceptions to make output look clean.
- **Never commit secrets.** No keys/tokens/passwords in code or logs — use env vars. Flag any secret you find.
- **No destructive commands without confirmation** (rm -rf, DROP/TRUNCATE, force-push, mass delete). State the impact first.
- **Prefer what exists.** Reuse the project's libraries and helpers before adding a dependency.

## Git
- Conventional commits (`feat:`, `fix:`, `refactor:`, `test:`). One logical change per commit.
- Never force-push shared branches; never commit straight to main if a PR flow exists.
- Don't commit generated files, secrets, or large binaries. Respect .gitignore.

## Definition of done
Implemented + tests/build/lint pass (output shown) + no unrelated code touched + risks/follow-ups noted.

---
_AgentKit bundle · tune to your team. Free generator: https://b19dvn7.github.io/agentkit/_
