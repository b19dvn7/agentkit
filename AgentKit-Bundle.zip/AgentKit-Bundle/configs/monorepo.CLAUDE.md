# CLAUDE.md — Monorepo (Turborepo/Nx)
# Production-tested agent config from the AgentKit bundle. Also valid as AGENTS.md / .cursorrules (rename + adjust the header).

## Project
> A Monorepo (Turborepo/Nx) project. Multi-package monorepo. Replace this with 1-2 sentences on what it does and who uses it.

## Stack
- Language: TypeScript
- Category: Special

## Commands
```bash
pnpm install   # install
pnpm dev   # run / dev
pnpm test   # test
pnpm lint   # lint
pnpm format   # format
pnpm typecheck   # type-check
```
Run the relevant command and show output before claiming a task is done.

## Code style — Monorepo (Turborepo/Nx)
- Respect package boundaries; no deep imports across packages.
- Use the task runner's caching; define clear dependency graphs.
- Shared config (tsconfig/eslint) via base packages.

## Stack-specific gotchas (read these first)
- Use NESTED CLAUDE.md/AGENTS.md per package for local context — root config + per-package overrides.
- Don't create circular package deps.
- Version/publish strategy (changesets) must be explicit.

## Testing
- Run only affected packages' tests in CI.

## How you should behave
- **Do only what is asked.** Implement exactly the requested change. Don't add features, refactors, or "while I'm here" improvements that weren't requested. Surface ideas; don't silently act on them.
- **Read before you write.** Open the relevant files first and match the existing patterns, naming, and structure. New code should be indistinguishable from the code already there.
- **Small, focused diffs.** Change the minimum needed. Never reformat or rename outside the task's scope.
- **Verify before claiming done.** Run the tests/build/linter and show the output. Never say it works without proof. If you can't verify, say so explicitly.
- **Ask when ambiguous.** One focused question beats a confident wrong guess.
- **No silent failures.** Handle errors and edge cases; don't swallow exceptions to make output look clean.
- **Never commit secrets.** No keys/tokens/passwords in code or logs — use env vars. Flag any secret you find.
- **No destructive commands without confirmation** (rm -rf, DROP/TRUNCATE, force-push, mass delete). State the impact first.
- **Prefer what exists.** Reuse the project's libraries and helpers before adding a dependency.

## Git
- Conventional commits (`feat:`, `fix:`, `refactor:`, `test:`). One logical change per commit.
- Never force-push shared branches; never commit straight to main if a PR flow exists.
- Don't commit generated files, secrets, or large binaries. Respect .gitignore.

## Definition of done
Implemented + tests/build/lint pass (output shown) + no unrelated code touched + risks/follow-ups noted.

---
_AgentKit bundle · tune to your team. Free generator: https://b19dvn7.github.io/agentkit/_
