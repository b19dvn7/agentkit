# Copy-paste Skills & Commands
Ready-to-use procedures for Claude Code / Cursor. Drop into your skills/commands dir (or paste the body into a prompt). Each follows the rule: **ordered steps, explicit stop conditions, proof required.**

---

## ship-check — pre-merge gate
```markdown
---
name: ship-check
description: Pre-merge checklist
---
On "ship-check", do IN ORDER, stop at first failure:
1. Run tests → paste summary.
2. Lint + type-check → paste results.
3. Build → confirm success.
4. `git diff --name-only main` → confirm every file relates to the task; flag any that don't.
5. Report PASS only if all green; else state exactly what failed.
Never report PASS without showing output of 1-3.
```

## triage — disciplined bug fixing
```markdown
---
name: triage
description: Reproduce → locate → minimal fix → regression test
---
On "triage <bug>":
1. Reproduce it. State the exact steps + observed vs expected.
2. Locate the root cause (not the symptom). Name the file:line.
3. Propose the MINIMAL fix. Wait for ok if it touches >2 files.
4. Implement. Add a regression test that fails before, passes after.
5. Run the suite. Show output.
Do not refactor unrelated code while fixing.
```

## add-endpoint — scaffold consistently
```markdown
---
name: add-endpoint
description: Add an API endpoint matching repo conventions
---
On "add-endpoint <name>":
1. Find an existing endpoint and mirror its structure exactly (validation, error handling, tests).
2. Add input validation at the boundary.
3. Write the handler thin; logic in the service layer.
4. Add tests: happy path + one validation failure + one auth failure.
5. Run tests. Show output. List files changed.
```

## review — self-review a diff before I see it
```markdown
---
name: review
description: Critically review the current diff
---
On "review":
1. Summarize what the diff does in 2 lines.
2. Flag SCOPE CREEP: anything changed that the task didn't require.
3. Flag MISSING TESTS for new logic.
4. Flag RISKS: security, perf, breaking changes, data loss.
5. Flag STYLE drift vs surrounding code.
Output a short table: issue | severity | file:line. No fixes yet — just the review.
```

## explain — onboard yourself to unfamiliar code
```markdown
---
name: explain
description: Map a feature before changing it
---
On "explain <feature>":
1. Trace the entry point → data flow → exit. List the files involved in order.
2. Note the key invariants and assumptions.
3. Identify what would break if changed.
Output a short map. Don't change anything.
```

## tighten — shrink a bloated config
```markdown
---
name: tighten
description: Cut an agent config down to signal
---
On "tighten":
1. List every rule in the config.
2. Mark each: KEEP (prevents a real recurring mistake) / CUT (vague, one-off, or default behavior).
3. Propose the trimmed file. Target < 60 lines for a single package.
Keep all stack-specific gotchas; cut generic platitudes.
```

---
_AgentKit bundle. Adapt freely. Free generator: https://b19dvn7.github.io/agentkit/_
