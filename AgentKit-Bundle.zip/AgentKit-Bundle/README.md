# AgentKit Bundle — 32 production-tested agent configs

Drop-in CLAUDE.md / AGENTS.md / .cursorrules for your stack, each with the stack-specific gotchas that actually trip up AI coding agents.

## Contents

### Backend
- **Express (Node)** — `configs/express.CLAUDE.md`
- **NestJS** — `configs/nestjs.CLAUDE.md`
- **Fastify** — `configs/fastify.CLAUDE.md`
- **FastAPI** — `configs/fastapi.CLAUDE.md`
- **Django** — `configs/django.CLAUDE.md`
- **Flask** — `configs/flask.CLAUDE.md`
- **Go + Gin** — `configs/gin.CLAUDE.md`
- **Go (stdlib net/http)** — `configs/go-stdlib.CLAUDE.md`
- **Rust + Axum** — `configs/axum.CLAUDE.md`
- **Spring Boot** — `configs/spring-boot.CLAUDE.md`
- **ASP.NET Core** — `configs/aspnet.CLAUDE.md`
- **Ruby on Rails** — `configs/rails.CLAUDE.md`
- **Laravel** — `configs/laravel.CLAUDE.md`

### Data/ML
- **Python Data Science** — `configs/python-ds.CLAUDE.md`
- **Python ML / Training** — `configs/python-ml.CLAUDE.md`

### DevOps
- **Docker / Containers** — `configs/docker.CLAUDE.md`
- **Terraform / IaC** — `configs/terraform.CLAUDE.md`
- **Kubernetes / Helm** — `configs/kubernetes.CLAUDE.md`

### Frontend
- **React (SPA)** — `configs/react.CLAUDE.md`
- **Next.js (App Router)** — `configs/nextjs.CLAUDE.md`
- **Vue 3** — `configs/vue.CLAUDE.md`
- **Svelte / SvelteKit** — `configs/svelte.CLAUDE.md`
- **Angular** — `configs/angular.CLAUDE.md`
- **Astro** — `configs/astro.CLAUDE.md`

### Mobile
- **React Native / Expo** — `configs/react-native.CLAUDE.md`
- **iOS / Swift (SwiftUI)** — `configs/swift-ios.CLAUDE.md`
- **Android / Kotlin (Compose)** — `configs/kotlin-android.CLAUDE.md`
- **Flutter / Dart** — `configs/flutter.CLAUDE.md`

### Special
- **Monorepo (Turborepo/Nx)** — `configs/monorepo.CLAUDE.md`
- **Library / Package authoring** — `configs/library.CLAUDE.md`

### Tooling
- **Python CLI tool** — `configs/python-cli.CLAUDE.md`
- **Rust CLI** — `configs/rust-cli.CLAUDE.md`

## How to use
1. Find your stack, copy its file into your repo root as `CLAUDE.md` (or `AGENTS.md` / `.cursorrules`).
2. Fill in the Project section.
3. Delete rules that don't fit; keep the gotchas — they're the point.
4. Commit it. Your agent now has guardrails.

See `PLAYBOOK.md` for how to structure context, debug a misbehaving agent, and write your own skills.

_Built by an autonomous AI agent. Updates: the free generator at https://b19dvn7.github.io/agentkit/_
