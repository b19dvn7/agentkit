# The Agent Playbook
### How to make an AI coding agent behave — context design, failure modes, and your own skills.

You bought 32 configs. This is the part that makes them work. Read it once; it changes how you work with any AI coding agent (Claude Code, Cursor, Copilot, and whatever comes next).

---

## 1. The one idea: context economy

An AI agent is only as good as the context it acts on. It has a finite attention budget and no memory of your project between sessions. A config file (`CLAUDE.md` / `AGENTS.md` / `.cursorrules`) is **persistent, high-priority context** — the things you'd otherwise repeat in every conversation.

So the test for *anything* you put in the file is:

> "Would I have to say this again next session? Does saying it once prevent a class of mistakes?"

If yes, it belongs. If it's a one-off, it doesn't. A bloated config is as bad as none — it buries the rules that matter. Aim for **signal, not coverage**.

---

## 2. What goes where

| Put it in… | …when it's |
|---|---|
| **CLAUDE.md / AGENTS.md** | A standing rule, command, convention, or guardrail that applies across the repo |
| **README** | Human onboarding, product context (the agent can read it, but it's not instructions) |
| **Inline code comments** | Why a specific non-obvious line exists |
| **A skill / command** | A repeatable multi-step procedure you trigger on demand (see §5) |

Common mistake: stuffing product backstory into the config. The agent doesn't need your funding history — it needs your build command, your test command, and the three things that will break if it touches them.

---

## 3. The seven failure modes (and the rule that kills each)

These are the recurring ways agents go wrong. Each maps to a rule already baked into your bundle configs — now you know *why*.

1. **Over-eager scope creep** — you ask for X, it also "improves" Y and Z.
   → *Rule:* "Do only what is asked. Surface ideas; don't act on them."
2. **Confident wrong guesses** — it invents an API or assumes an unstated requirement.
   → *Rule:* "Ask one focused question when ambiguous."
3. **The 'done' that isn't** — it claims success without running anything.
   → *Rule:* "Verify before claiming done — show the test/build output."
4. **Style drift** — new code that doesn't match the surrounding code.
   → *Rule:* "Read before you write; match existing patterns."
5. **The giant diff** — a 400-line change for a 10-line task.
   → *Rule:* "Small, focused diffs. Don't reformat unrelated lines."
6. **Silent swallowing** — wraps everything in try/except to make output look clean.
   → *Rule:* "No silent failures. Handle errors explicitly."
7. **Dangerous autonomy** — runs a destructive command without thinking.
   → *Rule:* "No destructive commands without confirming impact first."

When an agent misbehaves, identify which of these seven it is — the fix is almost always tightening the matching rule, not writing more rules.

---

## 4. Structuring context for real repos

**Small repo:** one config at the root. Done.

**Monorepo / large repo:** use **nested configs**. A root `CLAUDE.md` with shared rules (commit style, security, behavior), plus a per-package `CLAUDE.md` with that package's commands and gotchas. Agents read the nearest one for local context and inherit the root. This keeps each file short and relevant — context economy at the directory level.

**The 3-section minimum** that every config needs, in priority order:
1. **Commands** — how to install, run, test, lint. The agent can't verify without these.
2. **Gotchas** — the 3-6 things specific to this codebase that will break if mishandled.
3. **Behavior** — the universal guardrails (scope, verify, ask).

Everything else is optional polish.

---

## 5. Writing your own skills / commands

A *skill* (or *custom command*) is a named, repeatable procedure. Instead of re-explaining "run the full release checklist," you define it once and invoke it. Template:

```markdown
---
name: ship-check
description: Pre-merge checklist for this repo
---
When asked to "ship-check", do these IN ORDER and stop at the first failure:
1. Run the test command. Paste the summary.
2. Run the linter + type-checker. Paste results.
3. Run the build. Confirm it succeeds.
4. List every file changed vs main and confirm none are unrelated to the task.
5. Report: PASS only if all green, else exactly what failed.
Never report PASS without showing the output of steps 1-3.
```

Good skills share three traits: **ordered steps**, **explicit stop conditions**, and **proof required**. Keep one skill per procedure; don't build a mega-skill.

Ideas worth a skill in most repos: `ship-check`, `add-endpoint` (scaffold + test + wire), `triage` (reproduce → locate → minimal fix → regression test), `review` (read diff, flag scope creep + missing tests).

---

## 6. Debugging a misbehaving agent — a checklist

Work top to bottom; stop when fixed.

1. **Is the rule even loaded?** Confirm the config is at the right path and the tool reads it. (Cursor: `.cursorrules` at root. Claude Code: `CLAUDE.md`. Copilot: `.github/copilot-instructions.md`.)
2. **Is the rule specific enough?** "Write good code" does nothing. "No `any`; run `tsc --noEmit` before done" does.
3. **Is the context buried?** If the file is 600 lines, the agent is drowning. Cut to signal.
4. **Conflicting instructions?** A rule in the file vs a habit in the model — make the file explicit and primary ("these override defaults").
5. **Wrong altitude?** Telling it *how* when you should tell it *what* (or vice-versa). Match the rule to the failure mode in §3.
6. **Is it a context-window issue?** On long sessions, restate the critical 3 rules in your prompt; the file's influence fades as the conversation grows.

---

## 7. Treat the config as code

- It lives in version control. Changes go through review like anything else.
- When the agent makes a mistake worth preventing, add (or sharpen) one rule — then *delete* a stale one so the file doesn't bloat.
- Revisit quarterly. Tools change; your stack changes; the file should too.

---

## Appendix: format cheat-sheet

| Tool | File | Notes |
|---|---|---|
| Claude Code | `CLAUDE.md` (repo root; nested allowed) | "These override default behavior" carries weight |
| Cursor | `.cursorrules` (root) or `.cursor/rules/*` | Newer Cursor supports scoped rule files |
| GitHub Copilot | `.github/copilot-instructions.md` | Repo-wide instructions |
| Generic / multi-tool | `AGENTS.md` | Increasingly supported as a shared standard |

The *content* is 95% the same across tools — these configs port with a rename and a header tweak.

---

_AgentKit · built by an autonomous AI agent as a $0 bootstrap experiment. The free generator stays free: https://b19dvn7.github.io/agentkit/_
